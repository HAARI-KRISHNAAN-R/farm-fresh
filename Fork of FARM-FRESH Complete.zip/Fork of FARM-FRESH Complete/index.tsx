import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Leaf, ShoppingCart, Star, Filter, CreditCard, Brain, Bell, Users, Zap, Users2, Recycle, ChevronRight, ArrowRight, Send, X, LogIn, LogOut, Upload } from 'lucide-react'
import Link from "next/link"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { toast, useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const locations = {
  Coimbatore: {
    farmers: {
      Haari: {
        products: {
          Carrots: { price: 25, limit: 10 },
          Tomatoes: { price: 30, limit: 8 },
          Potatoes: { price: 20, limit: 15 }
        }
      }
    }
  },
  Erode: {
    farmers: {
      Sudhan: {
        products: {
          Carrots: { price: 23, limit: 12 },
          Tomatoes: { price: 28, limit: 10 },
          Potatoes: { price: 18, limit: 20 }
        }
      }
    }
  },
  Tiruppur: {
    farmers: {
      Alwin: {
        products: {
          Carrots: { price: 26, limit: 8 },
          Tomatoes: { price: 32, limit: 6 },
          Potatoes: { price: 22, limit: 12 }
        }
      }
    }
  },
  Salem: {
    farmers: {
      Ravi: {
        products: {
          Carrots: { price: 24, limit: 15 },
          Tomatoes: { price: 29, limit: 10 },
          Potatoes: { price: 19, limit: 18 }
        }
      }
    }
  },
  Karur: {
    farmers: {
      Vijay: {
        products: {
          Carrots: { price: 27, limit: 10 },
          Tomatoes: { price: 31, limit: 8 },
          Potatoes: { price: 21, limit: 14 }
        }
      }
    }
  }
}

export default function Component() {
  const [isAIChatOpen, setIsAIChatOpen] = useState(false)
  const [chatMessages, setChatMessages] = useState([
    { role: 'ai', content: 'Hello! How can I assist you with your FARM-FRESH order today?' }
  ])
  const [userInput, setUserInput] = useState('')
  const [isFilterOpen, setIsFilterOpen] = useState(false)
  const [selectedLocation, setSelectedLocation] = useState('')
  const [cart, setCart] = useState([])
  const [isCartOpen, setIsCartOpen] = useState(false)
  const [deliveryDetails, setDeliveryDetails] = useState({
    name: '',
    address: '',
    phone: ''
  })
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [isLoginDialogOpen, setIsLoginDialogOpen] = useState(false)
  const [loginCredentials, setLoginCredentials] = useState({ email: '', password: '' })
  const [isSeller, setIsSeller] = useState(false)
  const [newProduct, setNewProduct] = useState({
    name: '',
    price: '',
    limit: '',
    description: '',
    location: '',
    image: null
  })
  const [farmerDetails, setFarmerDetails] = useState({
    name: '',
    farmName: '',
    address: '',
    phone: '',
  })
  const { toast } = useToast()

  const handleSendMessage = (e) => {
    e.preventDefault()
    if (userInput.trim() === '') return

    const newUserMessage = { role: 'user', content: userInput }
    setChatMessages(prevMessages => [...prevMessages, newUserMessage])
    setUserInput('')

    // Simulate AI response (replace with actual AI integration)
    setTimeout(() => {
      const aiResponse = { role: 'ai', content: `Thank you for your question. Here's some information about "${userInput}": [AI-generated response would go here]` }
      setChatMessages(prevMessages => [...prevMessages, aiResponse])
    }, 1000)
  }

  const addToCart = (location, farmer, product, price, limit) => {
    if (!isLoggedIn) {
      toast({
        title: "Login Required",
        description: "Please log in to add items to your cart.",
        variant: "destructive",
      })
      setIsLoginDialogOpen(true)
      return
    }

    const existingItemIndex = cart.findIndex(item => 
      item.location === location && item.farmer === farmer && item.product === product
    )

    if (existingItemIndex !== -1) {
      const existingItem = cart[existingItemIndex]
      if (existingItem.quantity >= limit) {
        toast({
          title: "Quantity Limit Reached",
          description: `You can't add more than ${limit} ${product}(s) from this vendor.`,
          variant: "destructive",
        })
        return
      }
      const newCart = [...cart]
      newCart[existingItemIndex] = {
        ...existingItem,
        quantity: existingItem.quantity + 1
      }
      setCart(newCart)
    } else {
      setCart(prevCart => [...prevCart, { location, farmer, product, price, quantity: 1, limit }])
    }

    toast({
      title: "Added to Cart",
      description: `${product} has been added to your cart.`,
    })
  }

  const removeFromCart = (index) => {
    setCart(prevCart => prevCart.filter((_, i) => i !== index))
  }

  const updateQuantity = (index, newQuantity) => {
    setCart(prevCart => prevCart.map((item, i) => {
      if (i === index) {
        if (newQuantity > item.limit) {
          toast({
            title: "Quantity Limit Exceeded",
            description: `You can't add more than ${item.limit} ${item.product}(s) from this vendor.`,
            variant: "destructive",
          })
          return item
        }
        return { ...item, quantity: newQuantity }
      }
      return item
    }))
  }

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  const handleCheckout = () => {
    if (!isLoggedIn) {
      toast({
        title: "Login Required",
        description: "Please log in to complete your purchase.",
        variant: "destructive",
      })
      setIsLoginDialogOpen(true)
      return
    }
    // Implement checkout logic here
    console.log('Checkout with:', { cart, deliveryDetails })
    toast({
      title: "Order Placed",
      description: "Thank you for your order!",
    })
    setCart([])
    setIsCartOpen(false)
  }

  const handleLogin = (e) => {
    e.preventDefault()
    // Implement actual login logic here
    console.log('Login attempt with:', loginCredentials)
    setIsLoggedIn(true)
    setIsLoginDialogOpen(false)
    // For demonstration, set isSeller to true if email contains "seller"
    setIsSeller(loginCredentials.email.toLowerCase().includes('seller'))
    toast({
      title: "Logged In",
      description: "You have successfully logged in.",
    })
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setIsSeller(false)
    setCart([])
    toast({
      title: "Logged Out",
      description: "You have been logged out.",
    })
  }

  const handleAddProduct = (e) => {
    e.preventDefault()
    // Here you would typically send this data to your backend
    console.log('New product:', newProduct)
    console.log('Farmer details:', farmerDetails)
    toast({
      title: "Product Added",
      description: `${newProduct.name} has been added to your inventory.`,
    })
    // Reset the form
    setNewProduct({
      name: '',
      price: '',
      limit: '',
      description: '',
      location: '',
      image: null
    })
    setFarmerDetails({
      name: '',
      farmName: '',
      address: '',
      phone: '',
    })
  }

  const handleImageUpload = (e) => {
    const file = e.target.files[0]
    if (file) {
      // Here you would typically upload the file to your server or a cloud storage service
      // For this example, we'll just store the file object
      setNewProduct(prev => ({ ...prev, image: file }))
      toast({
        title: "Image Uploaded",
        description: `${file.name} has been uploaded.`,
      })
    }
  }

  return (
    <div className="bg-background min-h-screen flex flex-col">
      <header className="bg-primary text-primary-foreground py-6 sticky top-0 z-10">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Leaf className="h-8 w-8" />
              <h1 className="text-2xl font-bold">FARM-FRESH</h1>
            </div>
            <nav className="hidden md:flex space-x-4">
              <Link href="#features" className="text-primary-foreground hover:text-primary-foreground/80">Features</Link>
              <Link href="#ai-recommendations" className="text-primary-foreground hover:text-primary-foreground/80">AI Recommendations</Link>
              <Link href="#tracking" className="text-primary-foreground hover:text-primary-foreground/80">Order Tracking</Link>
              <Link href="#testimonials" className="text-primary-foreground hover:text-primary-foreground/80">Testimonials</Link>
              {isSeller && (
                <Link href="#seller" className="text-primary-foreground hover:text-primary-foreground/80">Seller Dashboard</Link>
              )}
            </nav>
            <div className="flex items-center space-x-2">
              {isLoggedIn && (
                <Button variant="ghost" onClick={() => setIsCartOpen(true)}>
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Cart ({cart.length})
                </Button>
              )}
              {isLoggedIn ? (
                <Button variant="ghost" onClick={handleLogout}>
                  <LogOut className="h-5 w-5 mr-2" />
                  Logout
                </Button>
              ) : (
                <Button variant="ghost" onClick={() => setIsLoginDialogOpen(true)}>
                  <LogIn className="h-5 w-5 mr-2" />
                  Login
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        <section className="bg-gradient-to-b from-primary to-background py-20 text-primary-foreground">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl font-bold mb-4">Your one-stop solution for fresh lifestyle cycle chain management</h2>
            <p className="text-xl mb-8">
              Connecting vendors and buyers of fresh vegetables and fruits with AI-driven insights
            </p>
            <div className="flex justify-center space-x-4">
              <Dialog open={isAIChatOpen} onOpenChange={setIsAIChatOpen}>
                <DialogTrigger asChild>
                  <Button size="lg" onClick={() => setIsAIChatOpen(true)}>Get Started <ArrowRight className="ml-2 h-4 w-4" /></Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle>AI Chat Assistant</DialogTitle>
                    <DialogDescription>
                      Ask questions about your order or FARM-FRESH services.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="flex flex-col h-[400px]">
                    <ScrollArea className="flex-grow pr-4">
                      {chatMessages.map((message, index) => (
                        <div key={index} className={`mb-4 ${message.role === 'user' ? 'text-right' : 'text-left'}`}>
                          <span className={`inline-block p-2 rounded-lg ${message.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                            {message.content}
                          </span>
                        </div>
                      ))}
                    </ScrollArea>
                    <form onSubmit={handleSendMessage} className="mt-4 flex">
                      <Input
                        type="text"
                        placeholder="Type your message..."
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                        className="flex-grow"
                      />
                      <Button type="submit" className="ml-2">
                        <Send className="h-4 w-4" />
                        <span className="sr-only">Send message</span>
                      </Button>
                    </form>
                  </div>
                </DialogContent>
              </Dialog>
              <Button size="lg" variant="outline" onClick={() => setIsFilterOpen(true)}>Advanced Filters</Button>
            </div>
          </div>
        </section>

        <Dialog open={isFilterOpen} onOpenChange={setIsFilterOpen}>
          <DialogContent className="sm:max-w-[625px]">
            <DialogHeader>
              <DialogTitle>Advanced Filters</DialogTitle>
              <DialogDescription>
                Filter products by location and farmer
              </DialogDescription>
            </DialogHeader>
            <div className="mt-4">
              <Select onValueChange={setSelectedLocation}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a location" />
                </SelectTrigger>
                <SelectContent>
                  {Object.keys(locations).map(location => (
                    <SelectItem key={location} value={location}>{location}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedLocation && (
                <Accordion type="single" collapsible className="mt-4">
                  {Object.entries(locations[selectedLocation].farmers).map(([farmer, data]) => (
                    <AccordionItem key={farmer} value={farmer}>
                      <AccordionTrigger>{farmer}</AccordionTrigger>
                      <AccordionContent>
                        <ul>
                          {Object.entries(data.products).map(([product, { price, limit }]) => (
                            <li key={product} className="flex justify-between items-center mb-2">
                              <span>{product} - ₹{price}/kg (Limit: {limit})</span>
                              <Button onClick={() => addToCart(selectedLocation, farmer, product, price, limit)}>
                                Add to Cart
                              </Button>
                            </li>
                          ))}
                        </ul>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={isCartOpen} onOpenChange={setIsCartOpen}>
          <DialogContent className="sm:max-w-[625px]">
            <DialogHeader>
              <DialogTitle>Your Cart</DialogTitle>
              <DialogDescription>
                Review your items and proceed to checkout
              </DialogDescription>
            </DialogHeader>
            <div className="mt-4">
              {cart.length === 0 ? (
                <p>Your cart is empty.</p>
              ) : (
                <>
                  {cart.map((item, index) => (
                    <div key={index} className="flex justify-between items-center mb-4">
                      <div>
                        <p>{item.product} from {item.farmer} ({item.location})</p>
                        <p>₹{item.price} x {item.quantity} = ₹{item.price * item.quantity}</p>
                        <p className="text-sm text-muted-foreground">Limit: {item.limit}</p>
                      </div>
                      <div className="flex items-center">
                        <Input
                          type="number"
                          min="1"
                          max={item.limit}
                          value={item.quantity}
                          onChange={(e) => updateQuantity(index, parseInt(e.target.value))}
                          className="w-16 mr-2"
                        />
                        <Button variant="outline" size="icon" onClick={() => removeFromCart(index)}>
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  <div className="mt-4">
                    <h4 className="font-semibold">Total: ₹{getTotalPrice()}</h4>
                  </div>
                  <div className="mt-4">
                    <h4 className="font-semibold mb-2">Delivery Details</h4>
                    <Input
                      placeholder="Name"
                      value={deliveryDetails.name}
                      onChange={(e) => setDeliveryDetails({...deliveryDetails, name: e.target.value})}
                      className="mb-2"
                    />
                    <Input
                      placeholder="Address"
                      value={deliveryDetails.address}
                      onChange={(e) => setDeliveryDetails({...deliveryDetails, address: e.target.value})}
                      className="mb-2"
                    />
                    <Input
                      placeholder="Phone"
                      value={deliveryDetails.phone}
                      onChange={(e) => setDeliveryDetails({...deliveryDetails, phone: e.target.value})}
                      className="mb-4"
                    />
                  </div>
                  <Button onClick={handleCheckout} className="w-full">Proceed to Checkout</Button>
                </>
              )}
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={isLoginDialogOpen} onOpenChange={setIsLoginDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Login</DialogTitle>
              <DialogDescription>
                Enter your credentials to access your account
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                  Email
                </label>
                <Input
                  id="email"
                  type="email"
                  value={loginCredentials.email}
                  onChange={(e) => setLoginCredentials({...loginCredentials, email: e.target.value})}
                  required
                />
              </div>
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                  Password
                </label>
                <Input
                  id="password"
                  type="password"
                  value={loginCredentials.password}
                  onChange={(e) => setLoginCredentials({...loginCredentials, password: e.target.value})}
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                Log In
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        {isSeller && (
          <section id="seller" className="py-20">
            <div className="container mx-auto px-4">
              <h2 className="text-3xl font-bold text-center mb-12">Seller Dashboard</h2>
              <Tabs defaultValue="add-product" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="add-product">Add Product</TabsTrigger>
                  <TabsTrigger value="inventory">Inventory</TabsTrigger>
                </TabsList>
                <TabsContent value="add-product">
                  <Card>
                    <CardHeader>
                      <CardTitle>Add New Product</CardTitle>
                      <CardDescription>Enter the details of your new product and your farmer information</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handleAddProduct} className="space-y-4">
                        <div>
                          <label htmlFor="product-name" className="block text-sm font-medium text-gray-700">
                            Product Name
                          </label>
                          <Input
                            id="product-name"
                            value={newProduct.name}
                            onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
                            required
                          />
                        </div>
                        <div>
                          <label htmlFor="product-price" className="block text-sm font-medium text-gray-700">
                            Price (₹)
                          </label>
                          <Input
                            id="product-price"
                            type="number"
                            value={newProduct.price}
                            onChange={(e) => setNewProduct({...newProduct, price: e.target.value})}
                            required
                          />
                        </div>
                        <div>
                          <label htmlFor="product-limit" className="block text-sm font-medium text-gray-700">
                            Quantity Limit
                          </label>
                          <Input
                            id="product-limit"
                            type="number"
                            value={newProduct.limit}
                            onChange={(e) => setNewProduct({...newProduct, limit: e.target.value})}
                            required
                          />
                        </div>
                        <div>
                          <label htmlFor="product-description" className="block text-sm font-medium text-gray-700">
                            Description
                          </label>
                          <Textarea
                            id="product-description"
                            value={newProduct.description}
                            onChange={(e) => setNewProduct({...newProduct, description: e.target.value})}
                            required
                          />
                        </div>
                        <div>
                          <label htmlFor="product-location" className="block text-sm font-medium text-gray-700">
                            Location
                          </label>
                          <Input
                            id="product-location"
                            value={newProduct.location}
                            onChange={(e) => setNewProduct({...newProduct, location: e.target.value})}
                            required
                          />
                        </div>
                        <div>
                          <label htmlFor="product-image" className="block text-sm font-medium text-gray-700">
                            Product Image
                          </label>
                          <Input
                            id="product-image"
                            type="file"
                            onChange={handleImageUpload}
                            accept="image/*"
                            required
                          />
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">Farmer Details</h4>
                          <Input
                            placeholder="Farmer Name"
                            value={farmerDetails.name}
                            onChange={(e) => setFarmerDetails({...farmerDetails, name: e.target.value})}
                            className="mb-2"
                            required
                          />
                          <Input
                            placeholder="Farm Name"
                            value={farmerDetails.farmName}
                            onChange={(e) => setFarmerDetails({...farmerDetails, farmName: e.target.value})}
                            className="mb-2"
                            required
                          />
                          <Input
                            placeholder="Farm Address"
                            value={farmerDetails.address}
                            onChange={(e) => setFarmerDetails({...farmerDetails, address: e.target.value})}
                            className="mb-2"
                            required
                          />
                          <Input
                            placeholder="Phone Number"
                            value={farmerDetails.phone}
                            onChange={(e) => setFarmerDetails({...farmerDetails, phone: e.target.value})}
                            className="mb-4"
                            required
                          />
                        </div>
                        <Button type="submit" className="w-full">
                          Add Product
                        </Button>
                      </form>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="inventory">
                  <Card>
                    <CardHeader>
                      <CardTitle>Your Inventory</CardTitle>
                      <CardDescription>Manage your product inventory</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {/* Add inventory management UI here */}
                      <p>Your inventory management interface will be displayed here.</p>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </section>
        )}

        <section id="features" className="py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Key Features</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <FeatureCard
                icon={<Star className="h-6 w-6" />}
                title="Vendor Feedback & Purchase Limits"
                description="Buyers can leave feedback, and vendors can set product limits."
              />
              <FeatureCard
                icon={<Filter className="h-6 w-6" />}
                title="Advanced Filters"
                description="Sort by location, product type, or vendor preferences."
              />
              <FeatureCard
                icon={<ShoppingCart className="h-6 w-6" />}
                title="Smart Cart & Payment System"
                description="Add items to a cart, choose delivery slots, and pay securely."
              />
              <FeatureCard
                icon={<Brain className="h-6 w-6" />}
                title="AI Recommendations"
                description="Personalized product suggestions based on buyer preferences."
              />
              <FeatureCard
                icon={<Bell className="h-6 w-6" />}
                title="Live Tracking & Notifications"
                description="Real-time order updates and push alerts for sales or deliveries."
              />
              <FeatureCard
                icon={<Users className="h-6 w-6" />}
                title="Community Forum"
                description="Share recipes, tips, and insights on fresh products and farming."
              />
              <FeatureCard
                icon={<Zap className="h-6 w-6" />}
                title="Dynamic Pricing & Deals"
                description="Vendors can adjust prices based on demand, and buyers enjoy seasonal discounts."
              />
              <FeatureCard
                icon={<Users2 className="h-6 w-6" />}
                title="Group Orders"
                description="Collaborate with others for bulk purchases and shared delivery costs."
              />
              <FeatureCard
                icon={<Recycle className="h-6 w-6" />}
                title="Sustainability Tools"
                description="Tips on repurposing excess products and insights on weather impacts."
              />
            </div>
          </div>
        </section>

        <section id="ai-recommendations" className="bg-muted py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">AI-Powered Recommendations</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {['Organic Apples', 'Fresh Tomatoes', 'Seasonal Berries'].map((item, index) => (
                <Card key={item}>
                  <CardHeader>
                    <CardTitle>{item}</CardTitle>
                    <CardDescription>Based on your preferences</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <img
                      src={`/placeholder.svg?height=200&width=300&text=${item}`}
                      alt={item}
                      className="w-full h-40 object-cover mb-4 rounded-md"
                    />
                    <Badge>Recommended</Badge>
                    <p className="mt-2">Price: ₹{(Math.random() * 100 + 20).toFixed(2)}/kg</p>
                    <Button className="w-full mt-4" onClick={() => addToCart('AI Recommendation', 'Best Farmer', item, parseFloat((Math.random() * 100 + 20).toFixed(2)), 10)}>Add to Cart</Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section id="tracking" className="py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Live Order Tracking</h2>
            <div className="space-y-4 max-w-2xl mx-auto">
              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div>
                  <h4 className="font-semibold">Order #1234</h4>
                  <p className="text-sm text-muted-foreground">Estimated delivery: 2:30 PM</p>
                </div>
                <Badge variant="outline">In Transit</Badge>
              </div>
              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div>
                  <h4 className="font-semibold">Order #5678</h4>
                  <p className="text-sm text-muted-foreground">Estimated delivery: 4:00 PM</p>
                </div>
                <Badge variant="outline">Preparing</Badge>
              </div>
            </div>
          </div>
        </section>

        <section id="testimonials" className="bg-muted py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">What Our Users Say</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { name: "Alice Johnson", role: "Buyer", quote: "FARM-FRESH has revolutionized how I shop for produce. The AI recommendations are spot-on!" },
                { name: "Bob Smith", role: "Vendor", quote: "As a small farm owner, this platform has helped me reach more customers and manage my inventory efficiently." },
                { name: "Carol Davis", role: "Buyer", quote: "The community forum is a great place to share recipes and tips. I've learned so much!" },
              ].map((testimonial, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle>{testimonial.name}</CardTitle>
                    <CardDescription>{testimonial.role}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p>"{testimonial.quote}"</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-8">Ready to get started?</h2>
            <p className="text-xl mb-8">Join FARM-FRESH today and experience the future of fresh produce management.</p>
            <div className="flex justify-center space-x-4">
              <Button size="lg" onClick={() => setIsAIChatOpen(true)}>Chat with AI <ChevronRight className="ml-2 h-4 w-4" /></Button>
              <Button size="lg" variant="outline">Contact Sales</Button>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-primary text-primary-foreground py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">About Us</h3>
              <p>FARM-FRESH is revolutionizing the fresh produce industry with AI-driven insights and seamless connections between vendors and buyers.</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><Link href="#" className="hover:underline">Home</Link></li>
                <li><Link href="#features" className="hover:underline">Features</Link></li>
                <li><Link href="#ai-recommendations" className="hover:underline">AI Recommendations</Link></li>
                <li><Link href="#tracking" className="hover:underline">Order Tracking</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
              <p>Email: info@farm-fresh.com</p>
              <p>Phone: (123) 456-7890</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Newsletter</h3>
              <p className="mb-4">Stay updated with our latest news and offers.</p>
              <form className="flex space-x-2">
                <Input type="email" placeholder="Enter your email" className="bg-primary-foreground text-primary" />
                <Button type="submit" variant="outline">Subscribe</Button>
              </form>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-primary-foreground/10 text-center">
            <p>&copy; 2023 FARM-FRESH. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

function FeatureCard({ icon, title, description }) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center space-x-2">
          {icon}
          <CardTitle>{title}</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <CardDescription>{description}</CardDescription>
      </CardContent>
    </Card>
  )
}